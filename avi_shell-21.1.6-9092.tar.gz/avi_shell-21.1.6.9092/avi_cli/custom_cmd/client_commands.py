############################################################################
# ========================================================================
# Copyright 2022 VMware, Inc.  All rights reserved. VMware Confidential
# ========================================================================
###

import subprocess
import json
import shlex


def cli_user_is_superuser(cli):
    """
    Check whether CLI user is a superuser
    :param cli:
    :return:
    """
    uri = '/api/user?name=%s' % cli.user
    json_rsp = cli._http_request('GET', uri)
    rsp = json.loads(json_rsp.text)
    if rsp['count'] == 0:
        cli.print_('Could not verify user privileges')
        return False
    return rsp['results'][0]['is_superuser']


def attach_se_shell(cli, args_dict, filter_dict):
    """
    ssh to se
    :param cli:
    :param args_dict:
    :param filter_dict:
    :return:
    """
    if not 'name' in args_dict:
        cli.print_('Please specify the service engine')
        return

    # Get the service engine object
    uri = '/api/serviceengine?name=%s' % args_dict['name']
    json_rsp = cli._http_request('GET', uri)
    rsp = json.loads(json_rsp.text)
    if rsp['count'] == 0:
        cli.print_('Service engine not found')
        return
    elif rsp['count'] > 1:
        cli.print_('Multiple service engines found. Please select the right one')
        return
    se_obj = rsp['results'][0]

    # Get the IP address for the associated reverse ssh tunnel
    uri = '/api/securechannelmapping?uuid=%s' % se_obj['uuid']
    json_rsp = cli._http_request('GET', uri)
    rsp = json.loads(json_rsp.text)
    if rsp['count'] == 0:
        cli.print_('Could not find a secure connection to the service engine')
        return
    rssh_ip = rsp['results'][0]['local_ip']

    options = '-p 5097'
    try:
        if not cli_user_is_superuser(cli):
            raise Exception('CLI user must have superuser privileges')

        uri = '/api/user-token'
        json_rsp = cli._http_request('POST', uri)
        rsp = json.loads(json_rsp.text)
        user = rsp['user']
        token = rsp['token']

        login_user = 'avidebuguser'
        if cli.user == 'admin':
            # Check if admin ssh is allowed
            uri = '/api/seproperties'
            json_rsp = cli._http_request('GET', uri)
            rsp = json.loads(json_rsp.text)
            se_runtime_props = rsp.get('se_runtime_properties')
            if se_runtime_props.get('admin_ssh_enabled'):
                login_user = 'admin'

        s_cmd_args = shlex.split('sshpass -p %s ssh %s -o UserKnownHostsFile=/dev/null -o '
                                 'StrictHostKeyChecking=no %s@%s'%(token, options,
                                                                   login_user, rssh_ip))
        subprocess.check_call(s_cmd_args)
    except Exception:
        s_cmd_args = shlex.split('ssh %s admin@%s'%(options, rssh_ip))
        subprocess.call(s_cmd_args)


def attach_cntlr_shell(cli, args_dict, filter_dict):
    """
    ssh to controller
    :param cli:
    :param args_dict:
    :param filter_dict:
    :return:
    """
    if not 'name' in args_dict:
        cli.print_('Please specify the controller')
        return

    if not cli_user_is_superuser(cli):
        cli.print_('User must have superuser privileges')
        return

    uri = '/api/cluster'
    json_rsp = cli._http_request('GET', uri)
    rsp = json.loads(json_rsp.text)
    name = args_dict['name']
    nodes = {node['name']:node['ip']['addr'] for node in rsp['nodes']}
    if name not in nodes.keys():
        cli.print_('Controller not found')
        return
    ip = nodes[name]

    uri = '/api/systemconfiguration'
    json_rsp = cli._http_request('GET', uri)
    rsp = json.loads(json_rsp.text)
    option = ''
    if rsp.get('docker_mode',False):
        option = '-p 5098'

    token_uri = '/api/user-token'
    try:
        json_rsp = cli._http_request('POST', token_uri)
        rsp = json.loads(json_rsp.text)
        user = rsp['user']
        token = rsp['token']

        login_user = 'admin' if cli.user == 'admin' else 'avidebuguser'
        s_cmd_args = shlex.split('sshpass -p %s ssh %s -o UserKnownHostsFile=/dev/null -o '
                                 'StrictHostKeyChecking=no %s@%s'%(token, option,
                                                                   login_user, ip))
        subprocess.check_call(s_cmd_args)
    except Exception:
        s_cmd_args = shlex.split('ssh admin@%s'%(ip))
        subprocess.call(s_cmd_args)
