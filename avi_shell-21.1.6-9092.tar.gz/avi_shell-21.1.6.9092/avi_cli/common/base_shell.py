############################################################################
# ========================================================================
# Copyright 2022 VMware, Inc.  All rights reserved. VMware Confidential
# ========================================================================
###

#FIXME: these are undefined vars in this file, pylint skip for now: can_clip, get_paste_buffer, write_to_paste_buffer
# pylint: disable=import-error, too-many-lines

import os
import sys
import json
import getpass
import requests
import urllib3
import readline
import subprocess
import time
import copy
import tempfile
import shlex
import _thread
import signal
import yaml
from platform import python_version
if int(python_version()[0]) >= 3:
    import urllib.parse
else:
    from urlparse import urlparse


from cmd2 import Cmd, Statekeeper
from requests_toolbelt import MultipartEncoder
from .exceptions import (WsError,
                         WsNotFoundError, WsBadRequestError, SocketError)

ALLOWED_BASH_COMMANDS_LIST = ["grep", "less", "more"]

if int(python_version()[0]) >= 3:
   try:
       from .login import (login, LoginUnknownError, LoginControllerNotReady,
           LoginCredentialsFailed, TokenCredentialsFailed)
   except ModuleNotFoundError:
       from login import (login, LoginUnknownError, LoginControllerNotReady,
           LoginCredentialsFailed, TokenCredentialsFailed)

BUFSIZE = 16384
SHELL_VERSION='21.1.6'

def _reformat_uri(uri):
    """
    Reformat uri
    :param uri:
    :return:
    """
    tokens = uri.split('#', 1)
    rem_tokens = []
    if len(tokens) > 1:
        rem_tokens = tokens[1].split('/', 1)
    return '/'.join([tokens[0]] + rem_tokens[1:])

class BaseShell(Cmd):
    def __init__(self, ws_addrs, user, password, token, tenant, local, debug, clear_sessions=False, restrict_bash=False):
        Cmd.__init__(self)
        # Disable warnings from urllib3
        if hasattr(urllib3, 'disable_warnings'):
            urllib3.disable_warnings()
        if hasattr(requests.packages.urllib3, 'disable_warnings'):
            requests.packages.urllib3.disable_warnings()
        if 'libedit' in readline.__doc__:
            readline.parse_and_bind("bind ^I rl_complete")
        else:
            readline.parse_and_bind("tab: complete")
        readline.set_completer_delims("""`!@#$%^&*()=[{]}\|;'",<>? """)
        self.ws_addrs = [ws_addr
                         if ws_addr.startswith('http') or ws_addr.startswith('https')
                         else 'https://' + ws_addr
                         for ws_addr in ws_addrs]
        self.user = user
        self.password = password
        self.token = token
        self.local = local
        self.tenant = tenant
        self.cookies = None
        self.timeout = 300
        # Flag has been used to restrict bash access in CLI container mode
        # e.g user accessed CLI using cli@<controller-ip>
        self.restrict_bash = restrict_bash
        self.headers = {
            'Content-Type': 'application/json',
            'X-Avi-Tenant': self.tenant,
            'Referer': self.ws_addrs[0]
        }
        self.debug = debug
        self.num_retries = 3
        self.clear_sessions = clear_sessions
        # ensure that we have the correct user and password
        self._check_webapp_addr_and_auth()
        self.last_accessed = time.time()
        self.session_expired = False
        self.session_timeout = 15
        self.stopped = False
        self.cmd_pending = False
        _thread.start_new_thread(self._check_session, ())

    def _redirect_output(self, statement):
        """
        Override redirect output with custom implementation
        :param statement:
        :return:
        Notes:
            01. CLI were able to execute commands even of bash access is restricted for user by using '|'
                We allow specific set of commands mentioned in bash_commands.yaml even with restricted bash access.
        """
#        if CliTerminalSettings.get_length() == 'TERMINAL_LENGTH_AUTO':
#            statement.parsed.pipeTo += ('more' if not statement.parsed.pipeTo
#                                        else '| more')
        if statement.parsed.pipeTo:
            # Refer Notes 01
            if self.restrict_bash:
                piped_statement = statement.parsed.pipeTo
                splitted_list = str(piped_statement).split("|")
                for item in splitted_list:
                    cmd = item.split()[0]
                    if cmd not in ALLOWED_BASH_COMMANDS_LIST:
                        self.print_("%s command not allowed for current user since bash access is restricted." % cmd)
                        return
            self.kept_state = Statekeeper(self, ('stdout',))
            self.kept_sys = Statekeeper(sys, ('stdout',))
            self.redirect = subprocess.Popen(statement.parsed.pipeTo,
                                             shell=True,
                                             stdin=subprocess.PIPE,
                                             stdout=self.kept_state.stdout,
                                             encoding='utf-8')
            sys.stdout = self.stdout = self.redirect.stdin
        elif statement.parsed.output:
            if (not statement.parsed.outputTo) and (not can_clip): #pylint: disable=undefined-variable
                raise EnvironmentError('Cannot redirect to paste buffer; '
                                       'install ``xclip`` and re-run to enable')
            self.kept_state = Statekeeper(self, ('stdout',))
            self.kept_sys = Statekeeper(sys, ('stdout',))
            if statement.parsed.outputTo:
                mode = 'w'
                if statement.parsed.output == 2 * self.redirector:
                    mode = 'a'
                fd = open(os.path.expanduser(statement.parsed.outputTo), mode)
                sys.stdout = self.stdout = fd
            else:
                sys.stdout = self.stdout = tempfile.TemporaryFile(mode="w+")
                if statement.parsed.output == '>>':
                    self.stdout.write(get_paste_buffer()) #pylint: disable=undefined-variable

    def _restore_output(self, statement):
        """
        Override restore output with custom implementation
        :param statement:
        :return:
        """
        if self.kept_state:
            if statement.parsed.output:
                if not statement.parsed.outputTo:
                    self.stdout.seek(0)
                    write_to_paste_buffer(self.stdout.read()) #pylint: disable=undefined-variable
            elif statement.parsed.pipeTo:
                #for result in self.redirect.communicate():
                #    self.kept_state.stdout.write(result or '')
                try:
                    # Close the file or pipe that stdout was redirected to
                    self.stdout.close()
                except BrokenPipeError:
                    pass
                self.redirect.wait()
            try:
                # Close the file or pipe that stdout was redirected to
                self.stdout.close()
            except BrokenPipeError:
                pass
            finally:
                # Restore self.stdout
                self.kept_state.restore()
                self.kept_state = None

            # Restore sys.stdout if need be
            if self.kept_sys is not None:
                self.kept_sys.restore()
                self.kept_sys = None

            self.redirect = None

    def _update_wsaddrs(self, port):
        """
        Update address
        :param port:
        :return:
        """
        new_ws_addrs = []
        for ws_addr in self.ws_addrs:
            parts = urllib.parse.urlparse(ws_addr)
            netloc = '%s:%s' % (parts.netloc.split(':')[0], port)
            new_ws_addrs.append('%s://%s' % (parts.scheme, netloc))
        self.ws_addrs = new_ws_addrs
        self.headers['Referer'] = self.ws_addrs[0]

    def _check_webapp_addr_and_auth(self):
        """
        Check webapp address
        :return:
        """
        MAX_LOGIN_ATTEMPTS = 5
        authorized = False
        attempts = 0
        alt_ports = [ 9443 ]
        while not authorized:
            try:
                motd = self._login()
                self.print_(motd)
                authorized = True
            except (requests.exceptions.ConnectionError, WsError):
                if not alt_ports:
                    self.print_('Could not connect to controller at %s. Please verify '
                                'the address of the controller and retry' % self.ws_addrs)
                    sys.exit(0)
                port = alt_ports.pop()
                self.print_('Could not connect to the controller. Trying an alternate port %s'
                            % port)
                self._update_wsaddrs(port)
                continue
            except LoginControllerNotReady:
                self.print_("Controller is not yet ready - Launching the shell "
                            "unauthenticated")
                self.print_("If the system is being upgraded, you can monitor "
                            "upgrade status")
                authorized = True
            except LoginUnknownError as e:
                self.print_('The controller at %s is not active. If this is not the '
                       'controller address, please restart the shell using the '
                       '--address flag to specify the address of the '
                       'controller.' % self.ws_addrs)
                self.print_(str(e))
            except TokenCredentialsFailed as e:
                self.print_(e)
                sys.exit(0)
            except LoginCredentialsFailed as e:
                # unauthorized
                # Base shell doesnt support self.server attribute
                # if self.server:
                #    self.print_("Wrong username and password combination. Please retry")
                #    sys.exit(0)

                # If we have exception for locked account for CLI handled it here
                reason = e.message if hasattr(e, 'message') else str(e)
                if "Account locked" in reason:
                    self.print_(json.loads(reason)["error"])
                    sys.exit(0)
                try:
                    if not self.user:
                        user = self.raw_input_with_no_history('Login: ')
                        self.user = user.strip()
                    passwd = getpass.getpass()
                    self.password = passwd.strip()
                except EOFError:
                    self.print_("\nExiting the CLI shell")
                    sys.exit(0)
            attempts += 1
            if attempts > MAX_LOGIN_ATTEMPTS:
                self.print_('Wrong username and password combination. Exiting now; '
                       'please try again later.')
                sys.exit(0)

    def _login(self):
        """
        Handle Login
        :return:

        Notes:
            01. If we kept CLI session idle for more than 15 minutes then api returns 401 for next call we made
                after wake up. We internally login again in this scenario but previously set headers got cleaned
                up for new login request. Fixed by updating headers with  previous set headers for new request.
        """
        if not self.user:
            raise LoginCredentialsFailed("Username is not specified")
        if self.local:
            password = None
            token = subprocess.check_output('/opt/avi/bin/get_auth --token', encoding='utf-8')
        elif self.token:
            password = None
            token = self.token
        else:
            password = self.password
            token = None
        optional_headers = {}
        if 'SSH_CONNECTION' in os.environ:
            optional_headers['X-AVI-REMOTE-CLIENT'] = os.environ['SSH_CONNECTION'].split()[0]
        for ws_addr in self.ws_addrs:
            try:
                optional_headers['X-AVI-USERAGENT'] = 'CLI'
                # Refer note 01
                optional_headers.update(self.headers)
                self.cookies, self.headers, self.rsp_data = login(
                    ws_addr, self.tenant, self.user, password,
                    token, self.timeout, optional_headers, self.clear_sessions)
                if SHELL_VERSION:
                    self.headers['X-Avi-Version'] = SHELL_VERSION
                if self.rsp_data.get('password_expired', False):
                    self.print_('')
                    self.print_('WARNING: Your password has expired. Configuration is now blocked')
                    self.print_('Please change your password using "passwd" command')
            except (requests.exceptions.ConnectionError,
                    requests.exceptions.RequestException):
                continue
            except LoginCredentialsFailed as e:
                reason = e.message if hasattr(e, 'message') else str(e)
                error_msg = json.loads(reason).get('error')
                if error_msg == 'Maximum concurrent session count reached.':
                    self.print_('')
                    self.print_('WARNING: Maximum concurrent session count has been reached.')
                    self.print_('Please clear the sessions using shell --clear-sessions')
                    sys.exit(0)
                if self.token:
                    # if the user entered a token and it fails, raise a
                    # different error so that we don't prompt the user for
                    # login/password since this may be a non-interactive session
                    raise TokenCredentialsFailed('Token authentication failed')
                else:
                    raise
            else:
                if ('linux_configuration' in self.rsp_data['system_config']
                        and 'motd' in self.rsp_data['system_config']['linux_configuration']):
                    return self.rsp_data['system_config']['linux_configuration']['motd']
                else:
                    return ''
        raise WsError('Could not connect to a controller at %s' % self.ws_addrs)

    def _http_request_no_err_handling(self, req_method, original_uri, params={},
                                      data={}, headers={}, files=[], ws_addr='',
                                      timeout=0):
        """
        Http request with no error handling
        :param req_method:
        :param original_uri:
        :param params:
        :param data:
        :param headers:
        :param files:
        :param ws_addr:
        :param timeout:
        :return:
        """
        self.logger.info('http_request_internal: %s %s \n\tparams=%s \n\tdata=%s' %
                  (req_method, original_uri, params, data))
        response = None

        # remove 'name' field from params
        try:
            del params['name']
        except KeyError:
            pass

        if ws_addr == '':
            ws_addr = self.ws_addrs[0]
        # Prepare the headers inside the retry loop as if there is
        # a 401, we do a re-login which will update the cookie and
        # headers.
        if headers or files:
            _headers = copy.copy(self.headers)
            _headers.update(headers)
        else:
            _headers = self.headers

        if files:
            # At this time, we only support one file
            file_path, file_name, file_uri = files[0]
            # we can't use context manager here, as fd used in execution
            # fd will be closed outside "with"
            f = open(file_path, 'rb')
            files_dict = {
                "file": (file_name, f, 'application/octet-stream'),
                "uri": file_uri
            }
            _data = MultipartEncoder(files_dict)
            _headers['Content-Type'] = _data.content_type
        else:
            _data = json.dumps(data)
        # If there is a fragment due to include_name, strip it out
        # of the URI
        if not original_uri.startswith('http'):
            uri = ws_addr + _reformat_uri(original_uri)
        else:
            uri = _reformat_uri(original_uri)

        if timeout == 0:
            timeout = self.timeout
        try:
            if req_method == 'GET':
                default_params = {'include_name' : True}
                if not params:
                    _params = default_params
                else:
                    _params = copy.copy(params)
                    _params.update(default_params)
                response = requests.get(uri, params=_params,
                                        headers=_headers,
                                        cookies=self.cookies,
                                        timeout=timeout, stream=True,
                                        verify=False)
            elif req_method == 'POST':
                response = requests.post(uri, params=params,
                                         data=_data,
                                         headers=_headers,
                                         cookies=self.cookies,
                                         timeout=timeout,
                                         verify=False)
            elif req_method == 'PUT':
                response = requests.put(uri, params=params,
                                        data=_data,
                                        headers=_headers,
                                        cookies=self.cookies,
                                        timeout=timeout,
                                        verify=False)
            elif req_method == 'DELETE':
                response = requests.delete(uri, params=params,
                                           headers=_headers,
                                           cookies=self.cookies,
                                           timeout=timeout,
                                           verify=False)
            else:
                raise Exception('Unknown HTTP request method: %s.' %
                                req_method)
        except:
            # Pass the same exception to the caller
            raise

        return response

    def _http_request(self, req_method, original_uri, params={},
                      data={}, headers={}, files=[]):
        """
        Http request error handling
        :param req_method:
        :param original_uri:
        :param params:
        :param data:
        :param headers:
        :param files:
        :return:
        """
        self.logger.info('http_request: %s %s \n\tparams=%s \n\tdata=%s' %
                  (req_method, original_uri, params, data))
        response = None

        headers['X-AVI-USERAGENT'] = 'CLI'
        for i in range(0, self.num_retries):
            try:
                response = self._http_request_no_err_handling(req_method, original_uri,
                                                              params, data, headers, files)
            except requests.exceptions.Timeout:
                if i == self.num_retries - 1:
                    self.logger.error('Connection to REST API server at %s timed '
                              'out.' % self.ws_addrs)
                time.sleep(0.25)
            except requests.exceptions.ConnectionError as err:
                if i == self.num_retries - 1:
                    self.logger.error('Error contacting REST API server at %s. (%s)' %
                              (self.ws_addrs, err))
                time.sleep(0.25)
            except requests.exceptions.RequestException as err:
                if i == self.num_retries - 1:
                    self.logger.error('Error contacting REST API server at %s. (%s)' %
                              (self.ws_addrs, err))
                time.sleep(0.25)
            else:
                if response.status_code == 401:
                    self._login()
                else:
                    break

        if response == None:
            self.logger.error('Response is None')
            raise WsError('Unable to receive a response from the '
                          'controller at %s' % self.ws_addrs)

        if response.status_code == 204:
            pass
        elif response.status_code == 404:
            raise WsNotFoundError('Could not find object.')
        elif response.status_code == 400:
            raise WsBadRequestError(response.text)
        elif response.status_code == 502:
            raise WsError('Could not reach the REST API on the controller')
        elif response.status_code >= 401:
            raise WsError(response.text)

        if self.is_attachment(response):
            self.logger.info('Received an attachment in response')
        else:
            self.logger.info('The response text is %s' % response.text)

        return response

    def _get_message(self, sock, residue=''):
        """
        Read socket message
        :param sock:
        :param residue:
        :return:
        """
        buf = ''
        while True:
            s = residue if residue else sock.recv(BUFSIZE)
            if not s:
                raise SocketError('Sockets were closed')
            residue = ''
            if isinstance(s, bytes):
                s = s.decode()
            parts = s.split('\r\n', 1)
            buf += parts[0]
            if len(parts) > 1:
                residue = parts[1]
                break
        return (buf, residue)

    def do_bash(self, arg):
        """
        Invocation for bash command
        :param arg:
        :return:
        """
        if self.restrict_bash:
            self.print_("Bash access not allowed for current user.")
            return

        if os.path.exists('/etc/motd'):
            subprocess.call(shlex.split('cat /etc/motd'))
        subprocess.call('bash')

    def is_attachment(self, response):
        """
        Check for attachment
        :param response:
        :return:
        """
        if ('content-disposition' in response.headers and
                'attachment' in response.headers['content-disposition']):
            return True
        return False

    def _refresh_session(self):
        """
        Refresh session
        :return:
        """
        self.last_accessed = time.time()
        self.session_expired = False

    def _check_session(self):
        """
        Check session
        :return:
        """
        while not self.stopped:
            # Wake up every minute and check for session expiry.
            time.sleep(60)
            session_timeout = self.session_timeout
            if not session_timeout:
                # infinite if set to 0.
                continue
            expires_at = self.last_accessed + (session_timeout*60)
            if expires_at < time.time() and not self.cmd_pending:
                self.session_expired = True
                cmd = 'kill -%d %d' % (signal.SIGINT, os.getpid())
                subprocess.call(cmd.split())
# End of file
