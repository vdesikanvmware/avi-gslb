############################################################################
# ========================================================================
# Copyright 2022 VMware, Inc.  All rights reserved. VMware Confidential
# ========================================================================
###

"""
==================
Avi CLI exceptions
==================

"""


class EmptyStatement(Exception):
    pass


class CmdError (Exception):
    pass


class NoCmdError (Exception):
    pass


class ArgumentError (Exception):
    pass


class ArgumentValueError (Exception):
    pass


class WsError (Exception):
    pass


class WsNotFoundError (WsError):
    pass


class WsBadRequestError (WsError):
    pass


class WsBadGatewayError (WsError):
    pass


class PbNotFoundError(Exception):
    pass


class SocketError(Exception):
    pass
