############################################################################
# ========================================================================
# Copyright 2022 VMware, Inc.  All rights reserved. VMware Confidential
# ========================================================================
###

import argparse
import readline
import os

LOG_DIR = "/var/lib/avi/log"


class Arguments:
    def __init__(self, args_dict):
        self.address = args_dict.get('address', [])
        self.batch_mode = args_dict.get('batch_mode', False)
        self.min_output = args_dict.get('min_output', False)
        self.local = args_dict.get('local', False)
        self.debug = args_dict.get('debug', False)
        self.file = args_dict.get('file')
        self.json = args_dict.get('json', False)
        self.password = args_dict.get('password', '')
        self.token = args_dict.get('token', '')
        self.tenant = args_dict.get('tenant', 'admin')
        self.user = args_dict.get('user', '')
        self.log = args_dict.get('log', 'cli.log')
        self.server = args_dict.get('server', False)
        self.port = args_dict.get('port', 5054)
        self.clear_sessions = args_dict.get('clear_sessions', False)
        self.restrict_bash = args_dict.get('restrict_bash', False)


def args_to_dict(args):
    return vars(args)


def dict_to_args(args_dict):
    return Arguments(args_dict)


def parse_args(argv, lbaasclient=False):
    args = argv
    cli_cmds = ''
    if '--' in argv:
        cli_cmds = argv[argv.index('--') + 1:]
        args = argv[:argv.index('--')]

    parser = argparse.ArgumentParser()
    parser.add_argument('--address', default=[],
                        action='append',
                        help=argparse.SUPPRESS if lbaasclient else 'Address of the REST API '
                                                                   'server')
    parser.add_argument('--batch-mode', action='store_true', default=False)
    # TODO: remove the min-output option
    parser.add_argument('--min-output', action='store_true', default=False)
    parser.add_argument('--local', default=False, action='store_true',
                        help='local shell login procedure')
    parser.add_argument('--debug', action='store_true', default=False)
    parser.add_argument('--file', help='Execute the CLI commands from this file')
    parser.add_argument('--json', action='store_true', default=False)
    parser.add_argument('--password', default='',
                        help=argparse.SUPPRESS if lbaasclient else 'Password for the REST API '
                                                                   'server')
    parser.add_argument('--token', default='',
                        help=argparse.SUPPRESS if lbaasclient else 'Token for the REST API '
                                                                   'server')
    parser.add_argument('--tenant', default='admin',
                        help=argparse.SUPPRESS if lbaasclient else '')
    parser.add_argument('--user', default='',
                        help=argparse.SUPPRESS if lbaasclient else 'Username for the REST API '
                                                                   'server')
    parser.add_argument('--log', default='cli.log',
                        help='Log file name')
    parser.add_argument('--server', default=False, action='store_true', 
                        help=argparse.SUPPRESS if lbaasclient else 'Use a client server model '
                                                                   'for CLI')
    parser.add_argument('--port', default=5054,
                        help=argparse.SUPPRESS if lbaasclient else 'Listening port for the CLI '
                                                                   'server')
    parser.add_argument('--clear-sessions', action='store_true', default=False)
    parser.add_argument('--restrict_bash', action='store_true', default=False)
    if lbaasclient:
        from .lbaas_utils import configure_lbaas
        # args = configure_lbaas(parser, args)
        return args, cli_cmds
    else:
        args = parser.parse_args(args[1:])
        return args, cli_cmds


def get_cli_dir(history=False):
    """
    Get CLI dir
    :param history:
    :return:

    Note:
    1. Handled case where os.path.exists check fails for some reason and try to create existed dir
       We simply pass through as its already exists
       e.g OSError: [Errno 17] File exists: '/root/.cli'
       Refer link: https://stackoverflow.com/questions/29541644/python-os-path-exists-reports-
                    false-when-files-is-there
    """
    # history file will keep at same location, which would be in no use while debugging
    try:
        if history:
            home_dir = os.path.expanduser('~')
            cli_dir = os.path.join(home_dir, '.cli')
            if not os.path.exists(cli_dir):
                os.makedirs(cli_dir)
            return cli_dir
        else:

            if not os.path.exists(LOG_DIR):
                os.makedirs(LOG_DIR)
            return LOG_DIR
    except OSError:
        # Refer note: 1
        pass


def _get_history_file():
    cli_dir = get_cli_dir(history=True)
    return '%s/history' % cli_dir


def read_history_file():
    try:
        readline.read_history_file(_get_history_file())
    except IOError:
        pass


def save_history_file():
    readline.set_history_length(1000)
    readline.write_history_file(_get_history_file())


# Copied here to avoid unwanted dependency in shell client bundle
def console_width():
    try:
        _, columns = os.popen('stty size', 'r').read().split()
    except ValueError:
        columns = 80
    return int(columns)
