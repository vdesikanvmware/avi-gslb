############################################################################
# ========================================================================
# Copyright 2022 VMware, Inc.  All rights reserved. VMware Confidential
# ========================================================================
###

import requests
import os
import json
import shlex
import subprocess

class LoginUnknownError(Exception):
    pass

class LoginCredentialsFailed(Exception):
    pass

class LoginControllerNotReady(Exception):
    pass

class TokenCredentialsFailed (Exception):
    pass

class LoginAuthenticationFailed (Exception):
    pass

def _login_failed(rsp):
    if rsp.status_code == 502:
        raise LoginUnknownError(rsp.text)
    elif rsp.status_code == 401:
        raise LoginCredentialsFailed(rsp.text)
    elif rsp.status_code == 403:
        raise LoginAuthenticationFailed(rsp.text)
    elif rsp.status_code == 503:
        raise LoginControllerNotReady(rsp.text)
    raise LoginUnknownError('Unknown error')

def login(ws_addr='https://localhost', tenant='admin', user='admin',
          password=None, token=None, timeout=30, optional_headers = {},
          clear_sessions = False, site_jwt=False):
    '''
    At this time, we use username/password based authentication for most
    of the cases. Only when you log into the shell and we spawn the avi
    CLI, will we use the CHAP authentication at this time using a public
    key/private key pair.
    In both cases, we will use the login semantics to establish a session
    encoded in a cookie and will access resources using this
    '''
    referer_header = ws_addr.rsplit(':', 1)[0] if ':443' in ws_addr else ws_addr
    # Get a CSRF token by touching the initial-data page
    rsp = requests.get(os.path.join(ws_addr, 'api/initial-data'), verify=False,
                       timeout=timeout)
    cookies = dict(rsp.cookies)
    headers = {
        'Content-Type' : 'application/json',
        'X-Avi-Tenant' : tenant,
        'Referer'      : referer_header
    }

    if rsp.status_code != 200:
        _login_failed(rsp)
        return

    if 'csrftoken' in cookies:
        headers['X-CSRFToken'] = cookies['csrftoken']

    headers.update(optional_headers)
    login_api = 'login'

    if clear_sessions and site_jwt:
        login_api = login_api+"?clear_sessions&site_jwt"
    elif clear_sessions:
        login_api = login_api+"?clear_sessions"
    elif site_jwt:
        login_api = login_api+"?site_jwt"
    
    login_req = {'username' : user, 'password' : password, 'token' : token}
    rsp = requests.post(os.path.join(ws_addr, login_api), verify=False,
                        timeout=timeout, cookies=cookies,
                        headers=headers, data=json.dumps(login_req))
    
    if rsp.status_code != 200:
        _login_failed(rsp)
        return

    # Cache the session id from the cookies
    cookies = dict(rsp.cookies)
    headers['X-CSRFToken'] = cookies['csrftoken']
    return (cookies, headers, rsp.json())

def authenticate(ws_addr='https://localhost', tenant='admin', user='admin',
          password=None, token=None, timeout=30, optional_headers = {}):
    referer_header = ws_addr.rsplit(':', 1)[0] if ':443' in ws_addr else ws_addr
    headers = {
        'Content-Type' : 'application/json',
        'X-Avi-Tenant' : tenant,
        'Referer'      : referer_header
    }
    headers.update(optional_headers)

    login_req={'username':user, 'password':password, 'token':token}
    rsp = requests.post(os.path.join(ws_addr, 'api/check-password'), verify=False, 
            timeout=timeout, headers = headers,
            data = json.dumps(login_req))

    if rsp.status_code != 200:
        _login_failed(rsp)
        return

def login_with_session(ws_addr='https://localhost', tenant='admin', cookies={}):
    referer_header = ws_addr.rsplit(':', 1)[0] if ':443' in ws_addr else ws_addr
    headers = {
        'Content-Type' : 'application/json',
        'X-Avi-Tenant' : tenant,
        'Referer'      : referer_header
    }
    if cookies.get('csrftoken'):
        headers['X-CSRFToken'] = cookies.get('csrftoken')
    return cookies, headers, {}

def logout(cookies, headers, ws_addr='https://localhost', timeout=30):
    rsp = requests.post(os.path.join(ws_addr, 'logout'), verify=False,
                        timeout=timeout, cookies=cookies,
                        headers=headers)

def get_username_token(user='admin', hours=None):
    env = os.environ.copy()
    env['PYTHONPATH'] = '/opt/avi/python/lib'
    cmd = '/opt/avi/python/bin/portal/manage.py gen_auth_token --user=%s' % user
    if hours:
        cmd += ' --hours=%s' % hours
    response = subprocess.run(shlex.split(cmd), close_fds=True, env=env, capture_output=True,  encoding='utf-8')
    #This guy returns the command as well
    #response = response.stdout.split('\n')[1]
    rsp = json.loads(response.stdout)
    username = rsp['username']
    token = rsp['token']
    return username, token

def get_system_user_token():
    rsp = requests.post('https://localhost/api/system-user-token', verify=False)
    if rsp.status_code != 200:
        return None
    try:
        data = rsp.json()
    except ValueError as e:
        raise(e)
    return data['token']
