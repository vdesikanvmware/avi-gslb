#!/usr/bin/python3
############################################################################
# ========================================================================
# Copyright 2022 VMware, Inc.  All rights reserved. VMware Confidential
# ========================================================================
###

# pylint: disable=import-error, too-many-lines
import sys
#check is added for FT to run as '/opt/avi/python/lib' won't
#be in sys.path in dev boxes and jenkins
if '/opt/avi/python/lib' in sys.path:
    sys.path.remove('/opt/avi/python/lib')

import getpass
import json
import logging
import os
import readline
import shlex
import socket
import subprocess
import threading
import time
from platform import python_version
if int(python_version()[0]) >= 3:
    import urllib.parse
else:
    from urlparse import urlparse


import uuid
import traceback
from tempfile import NamedTemporaryFile

from cmd2 import Cmd, ParsedString
import yaml
from avi_cli.common.shell_utils import parse_args, args_to_dict
from avi_cli.common.shell_utils import (
    read_history_file, save_history_file, console_width)
from avi_cli.custom_cmd.client_commands import (
    attach_se_shell, attach_cntlr_shell)
from avi_cli.common.base_shell import BaseShell, SocketError, BUFSIZE

DEFAULT_PROMPT = ': > '

REMOVED_KEYWORDS = ['_load', '_relative_load', 'cmdenvironment', 'ed',
                    'l', 'li', 'list', 'load', 'pause', 'shell', 'shortcuts',
                    'show', 'exit', 'save', 'set']

class RemoteShell(BaseShell):
    """
    Base class for shell client
    """
    def __init__(self, args):
        ws_addr = (args.address or ['https://localhost'])
        self.server = False
        BaseShell.__init__(self, ws_addr, args.user, args.password,
                           args.token, args.tenant, args.local, args.debug, args.clear_sessions, args.restrict_bash)
        self.keywords = [keyword for keyword in self.keywords if keyword not in REMOVED_KEYWORDS]
        #self.keywords = []
        self.old_completer = readline.get_completer()
        readline.set_completer(self.complete)
        readline.parse_and_bind(self.completekey+": complete")

        # Base shell may have prompted the user to enter the password if the combination
        # was incorrect. Fix up args user and password
        args.user = self.user
        args.password = self.password
        self.args = args
        self.ip = urllib.parse.urlparse(self.ws_addrs[0]).netloc
        self.ip = self.ip.split(":")[0]
        self.port = args.port
        self.stdio_sock = self.ctrl_sock = self.file_sock = None
        self.completion_matches = None
        self.prompt = DEFAULT_PROMPT
        self.logger = logging.getLogger()
        self.logger.setLevel(logging.DEBUG if args.debug else logging.INFO)
        self.exp_seq_num = 0
        try:
            self.create_socks()
        except socket.error:
            self.print_("Unable to connect to the CLI shell server")
            self.print_("Please verify that the CLI shell server is enabled")
            if "https://localhost" in ws_addr:
                # Prompt how to enable the remote CLI shell server
                self.print_("You can launch /opt/avi/python/bin/cli/bin/shell.py to "
                            "enable remote CLI shell")
            sys.exit(1)
        self.cached_line = ''

    def func_named(self, arg):
        """
        calling function for do_<command>
        :param arg:
        :return:
        """
        result = None
        if self.abbrev:   # accept shortened versions of commands
            funcs = [fname for fname in self.keywords if fname.startswith(arg)]
            if len(funcs) == 1:
                result = 'do_' + funcs[0]
        return result

    def print_(self, s):
        """
        Display output
        :param s:
        :return:
        """
        print(s, flush=True)

    def _stream_message_to_stdout(self, sock, residue=''):
        """
        Stream message string to stdout
        :param sock:
        :param residue:
        :return:
        """
        buf = ''
        while True:
            s = residue if residue else sock.recv(BUFSIZE)
            if not s:
                raise SocketError('Sockets were closed')
            residue = ''
            parts = s.decode().split('\r\n', 1)
            buf += parts[0]
            if len(parts) > 1:
                residue = parts[1]
                break
            parts = buf.split('\n', 1)
            while len(parts) > 1:
                sys.stdout.write(parts[0] + '\n')
                sys.stdout.flush()
                buf = parts[1]
                parts = buf.split('\n', 1)
        if buf:
            sys.stdout.write(buf)
            sys.stdout.flush()
        return residue

    def pseudo_raw_input(self, prompt):
        """
        user input
        :param prompt:
        :return:
        """
        try:
            line = Cmd.pseudo_raw_input(self, prompt)
        except KeyboardInterrupt:
            print()
            line = ''
        if self.session_expired:
            self.print_('Session expired - Auto logging out...')
            return 'quit\n'
        self._refresh_session()
        return line

    def was_cmd_exit(self):
        """
        Exit call of command
        :return:
        """
        cmd = self.cached_line.strip().lower()
        if cmd == 'eof' or cmd == 'quit' or cmd == 'q':
            return True
        if cmd == 'exit' and self.exc_raised:
            return True
        return False

    def raw_input_(self, prompt):
        """
        Input prompt
        :param prompt:
        :return:
        """
        return input(prompt)

    def raw_input_with_no_history(self, prompt):
        """
        Input without history
        :param prompt:
        :return:
        """
        self.stdout.write(prompt)
        self.stdout.flush()
        return self.stdin.readline()

    def getpass_(self, prompt):
        """
        Get password
        :param prompt:
        :return:
        """
        return getpass.getpass(prompt)

    def close_socks(self):
        """
        Close socket
        :return:
        """
        try:
            self.stdio_sock.shutdown(socket.SHUT_RDWR)
            self.stdio_sock.close()
        except socket.error:
            pass
        try:
            self.ctrl_sock.shutdown(socket.SHUT_RDWR)
            self.ctrl_sock.close()
        except socket.error:
            pass
        try:
            self.file_sock.shutdown(socket.SHUT_RDWR)
            self.file_sock.close()
        except socket.error:
            pass

    def _complete(self, text, state):
        """
        Invocation for complete
        :param text:
        :param state:
        :return:
        """
        if state == 0:
            origline = readline.get_line_buffer()
            line = origline.lstrip()
            stripped = len(origline) - len(line)
            begidx = readline.get_begidx() - stripped
            endidx = readline.get_endidx() - stripped
            cmpl_info = {'type': 'completion', 'origline': origline, 'text': text,
                         'begidx': begidx, 'endidx': endidx,
                         'state': state, 'width': console_width()}
            self.ctrl_sock.sendall(json.dumps(cmpl_info).encode() + '\r\n'.encode())
            buf, _ = self._get_message(self.ctrl_sock)
            res = json.loads(buf)
            self.completion_matches = res['res']
        return self.completion_matches[state]

    def complete(self, text, state):
        """
        invocation for complete
        :param text:
        :param state:
        :return:
        """
        return self.retry(self._complete, text, state)

    def create_socks(self):
        """
        create a socket
        :return:
        """
        self.session_id = str(uuid.uuid4()).split('-')[-1]
        self.stdio_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.stdio_sock.connect((self.ip, self.port))
        client_info = {
            'session_id': self.session_id, 'conn_type': 'stdio',
            'params': json.dumps(args_to_dict(self.args)),
            'cookies': json.dumps(self.cookies)
        }
        self.stdio_sock.sendall(json.dumps(client_info).encode())

        self.ctrl_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.ctrl_sock.connect((self.ip, self.port))
        client_info = {
            'session_id': self.session_id, 'conn_type': 'ctrl'
        }
        self.ctrl_sock.sendall(json.dumps(client_info).encode() + '\r\n'.encode())

        self.file_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.file_sock.connect((self.ip, self.port))
        client_info = {
            'session_id': self.session_id, 'conn_type': 'file'
        }
        self.file_sock.sendall(json.dumps(client_info).encode())
        self.exp_seq_num = 0
        self.recv_seq_num = 0
        # TBD: May need a handshake here. For now, sleep and see if that fixes.
        time.sleep(1)
        th = threading.Thread(target=self.file_server)
        th.daemon = True
        th.start()

    def create_socks_with_retry(self):
        """
        Retry socket creation
        :return:
        """
        attempts = 0
        MAX_ATTEMPTS = 5
        self.close_socks()
        while attempts < MAX_ATTEMPTS:
            try:
                self.create_socks()
                return
            except (socket.error, SocketError):
                attempts += 1
                time.sleep(attempts)
        raise SocketError("Unable to connect to the controller -- Please retry the command")

    def retry(self, f, *args, **kwargs):
        """
        Retry socket creation
        :param f:
        :param args:
        :param kwargs:
        :return:
        """
        try:
            return f(*args, **kwargs)
        except (socket.error, SocketError):
            if self.was_cmd_exit():
                return self._STOP_AND_EXIT
            self.create_socks_with_retry()
            return f(*args, **kwargs)

    def _one_io(self, line, flush_stdout=False):
        """
        Interacting with socket and send user input line to socket and collect output
        :param line:
        :param flush_stdout:
        :return:
        """
        if not flush_stdout:
            self.cached_line = line
            self.stdio_sock.sendall(line.encode() + '\n'.encode())
        # We will now receive data of the following format
        # - whatever needs to be displayed on stdout
        # - \r\n to terminate the stdout
        # - prompt
        # - \r\n to terminate the prompt
        residue = ''
        residue = self._stream_message_to_stdout(self.stdio_sock, residue)
        data, residue = self._get_message(self.stdio_sock, residue)
        try:
            data_dict = json.loads(data)
            self.prompt = data_dict['prompt']
            self.recv_seq_num = data_dict['seq_num']
            tenant = data_dict.get('tenant', 'admin')
            if tenant != self.tenant:
                self.tenant = tenant
                self.headers['X-Avi-Tenant'] = self.tenant
        except ValueError:
            self.prompt = data
        return residue

    def _one_cmd(self, line, flush_stdout=False):
        """
        Handle single line input
        :param line:
        :param flush_stdout:
        :return:
        """
        self.cmd_pending = True
        while True:
            residue = self._one_io(line, flush_stdout=flush_stdout)
            if residue == '\r\n':
                break
            if self.prompt.startswith('**'):
                self.prompt = self.prompt[2:]
                line = self.getpass_(self.prompt)
            else:
                line = self.raw_input_(self.prompt)
        self.cmd_pending = False

    def _one_cmd_with_seq(self, line):
        """
        Command with sequence
        :param line:
        :return:
        """
        self.cmd_pending = True
        flush_stdout = False
        while True:
            self._one_cmd(line, flush_stdout=flush_stdout)
            if (not self.recv_seq_num or
                    self.recv_seq_num >= self.exp_seq_num):
                break
            flush_stdout = True
        self.cmd_pending = False

    def do_set(self, arg):
        """
        Override cmd2's do_set handler
        :param arg:
        :return:

        Notes:
            01. Need to override set method to parse parameters, latest do_set expecting 2 values, which
                is 3 earlier. Our arg parser return 3 values.
        """
        # Refer note 01
        statement, paramName, val = arg.parsed.raw.split(None, 2)
        arg.settable = (paramName, val)
        return self.default(arg.parsed.raw)

    def default(self, line):
        """
        This is default function get calls when do_<command> not matched with any of
        implementation
        :param line:
        :return:

        Notes:
        1. Server is not processing ctrl+C signal when processing a command which
        prints output continuously due to python3 side effect
        2. Reconnecting socket on ctrl+c signal as a workaround
        3. we can't send explicit signal as server is processing another request and not
        processes until it gets completed
        """
        if isinstance(line, ParsedString):
            line = line.full_parsed_statement()
        self.exc_raised = False
        self.exp_seq_num += 1
        try:
            self._one_cmd_with_seq(line)
        except KeyboardInterrupt:
            # Refer Note 1
            self.create_socks_with_retry()
        except (socket.error, SocketError):
            self.exc_raised = True
        if self.was_cmd_exit():
            return self._STOP_AND_EXIT
        if self.exc_raised:
            print('Lost connectivity to the controller -- Retrying to connect')
            self.create_socks_with_retry()
            # Resynchronize prompts
            self.default('')
            self.print_("Re-established connectivity -- Please retry the command")

    def do_reset(self, line):
        """
        Invocation for reset command
        :param line:
        :return:
        """
        self.print_("Resetting the session with the server")
        time.sleep(1)
        self.create_socks_with_retry()
        os.system('reset')

    def do_attach(self, line):
        """
        Invocation for attach command
        :param line:
        :return:
        """
        parts = shlex.split(line)
        if parts[0] != 'serviceengine' and parts[0] != 'controller':
            self.print_('Error: attach command is applicable only to controller or serviceengine')
            return
        args_dict = {'name' : parts[1]}
        filter_dict = {}
        if parts[0] == 'serviceengine':
            attach_se_shell(self, args_dict, filter_dict)
        elif parts[0] == 'controller':
            attach_cntlr_shell(self, args_dict, filter_dict)

    def do_watch(self, line):
        """
        Custom watch implementation for shell client

        Note 1: In p2 support, we need not to parse line for watch, but in p3 is needed,
                as we are sending line to socket it was going like "watch show serviceengine"
                but actually we expect to go like "show serviceengine"
                If socket receives command with watch then its invoking do_watch of shell.py
                and being child process it will not terminate and executing forever
        :param line:
        :return:
        """
        timeout = 2
        while True:
            # Updated timeout for watch from command
            # pass interval in command itself
            # e.g watch interval 10 show serviceengine
            try:
                if 'interval' in line:
                    timeout = int(line.split()[1])
            except Exception as e:
                self.print_("Not a valid command")
                return
            # Refer Note: 1
            line = line[line.index('show'):]
            self.default(line)
            time.sleep(timeout)
            os.system('clear')

    def do_edit(self, line):
        """
        Invocation of edit command
        :param line:
        :return:
        """
        cmpl_info = {'type' : 'read_ctxt'}
        self.ctrl_sock.sendall(json.dumps(cmpl_info).encode() + '\r\n'.encode())
        buf, _ = self._get_message(self.ctrl_sock)
        res = json.loads(buf)
        if not res.get('res', ''):
            self.print_("The 'edit' keyword is only available within a submode")
            return
        with NamedTemporaryFile(delete=False, mode="w+") as f:
            # convert json string data to yaml data to dump in yaml format
            yaml_data = yaml.safe_load(res['res'])
            f.write(yaml.dump(yaml_data, default_flow_style=False))
            filename = f.name
        cmd = 'vi %s' % filename
        subprocess.call(cmd.split())
        with open(filename) as f:
            s = f.read()

        os.unlink(filename)
        try:
            json_data = json.loads(json.dumps(yaml.safe_load(s)))
            cmpl_info = {'type': 'write_ctxt', 'data': json_data}
        except Exception:
            self.print_('Error in parsing the edited content')
            return
        self.ctrl_sock.sendall(json.dumps(cmpl_info).encode() + '\r\n'.encode())
        buf, _ = self._get_message(self.ctrl_sock)

    def do_new(self, line):
        """
        Invocation for new command
        :param line:
        :return:
        """
        cmpl_info = {'type' : 'read_new_ctxt', 'cmd_name': line}
        self.ctrl_sock.sendall((json.dumps(cmpl_info) + '\r\n').encode())
        buf, _ = self._get_message(self.ctrl_sock)
        res = json.loads(buf)
        if not res.get('res', ''):
            self.print_("The 'new' keyword is only available within a submode")
            return
        with NamedTemporaryFile(delete=False, mode="w+") as f:
            yaml_data = yaml.safe_load(res['res'])
            s = yaml.dump(yaml_data, default_flow_style=False)
            file_lines = [''.join(['# ', x, '\n']) for x in s.split('\n')]
            f.writelines(file_lines)
            edit_yaml_data = yaml.safe_load(res['edit_data'])
            if edit_yaml_data:
                s = yaml.dump(edit_yaml_data, default_flow_style=False)
                f.writelines(s)
            filename = f.name
        cmd = 'vi %s' % filename
        subprocess.call(cmd.split())
        with open(filename) as f:
            s = f.read()
        os.unlink(filename)
        try:
            json_data = json.loads(json.dumps(yaml.safe_load(s)))
            cmpl_info = {'type': 'write_new_ctxt', 'data': json_data, 'cmd_name': line}
        except Exception:
            self.print_('Error in parsing the new object content')
            return
        self.ctrl_sock.sendall((json.dumps(cmpl_info) + '\r\n').encode())
        buf, _ = self._get_message(self.ctrl_sock)

    def do_terminal(self, line):
        """
        Invocation of terminal command
        :param line:
        :return:
        """
        if line.startswith('session_timeout'):
            parts = line.split('session_timeout')
            if len(parts) > 1 and parts[1]:
                self.session_timeout = int(parts[1])
        self.default('terminal %s' % line)

    def cmdloop(self):
        """ Overrides the cmd2 method so that our version does not try to use
        arguments passed from the terminal. """
        # Add this one cmd to synchronize with the server side as we get a \n otherwise.
        self.default('')
        self._cmdloop()

    def download_attachment(self, file_info, residue):
        """
        Download the attachment
        :param file_info:
        :param residue:
        :return:
        """
        full_filename = file_info['filename']
        content_length = int(file_info['content_length'])
        try:
            with open(full_filename, 'wb') as f:
                if residue:
                    if isinstance(residue, str):
                        residue = residue.encode()
                    f.write(residue)
                content_length -= len(residue)
                while content_length:
                    buf_sz = min(content_length, 16*1024)
                    buf = self.file_sock.recv(buf_sz)
                    if not buf:
                        break
                    f.write(buf)
                    content_length -= len(buf)
            self.file_sock.sendall('DONE'.encode())
        except:
            traceback.print_exc()
            self.file_sock.sendall('DONE'.encode())

    def upload_file(self, filename):
        """
        Upload a file
        :param filename:
        :return:
        """
        if not os.path.exists(filename):
            content_length = 0
        else:
            content_length = os.path.getsize(filename)
        file_response_info = {'content_length' : content_length}
        self.file_sock.sendall(json.dumps(file_response_info).encode())
        self.file_sock.sendall(('\r\n').encode())
        if content_length:
            with open(filename, 'rb') as f:
                while True:
                    buf = f.read(16*1024)
                    if not buf:
                        break
                    self.file_sock.sendall(buf)

    def _file_server(self):
        """
        Upload file server
        :return:
        """
        while True:
            residue = ''
            buf, residue = self._get_message(self.file_sock, residue)
            file_info = json.loads(buf)
            if file_info['type'] == 'attachment':
                self.download_attachment(file_info, residue)
            elif file_info['type'] == 'file':
                self.upload_file(file_info['filename'])

    def file_server(self):
        """
        File server
        :return:
        """
        try:
            self._file_server()
        except:
            pass


def run():
    """
    start of execution
    :return:
    """
    args, cli_cmds = parse_args(sys.argv, lbaasclient=False)

    cli_cmd_file = args.file
    args.file = None
    read_history_file()
    app = RemoteShell(args)
    if cli_cmds:
        for cmd in ''.join(cli_cmds).split(';'):
            app._one_cmd(cmd)
    elif cli_cmd_file:
        app.echo = True
        with open(cli_cmd_file, 'r') as f:
            for _, cmd in enumerate(f):
                app._one_cmd(cmd)
    else:
        app.cmdloop()
    app.close_socks()
    save_history_file()
    app.stopped = True


def main():
    try:
        run()
    except KeyboardInterrupt:
        print("\nExiting the CLI shell")

if __name__ == '__main__':
    main()
# End of file
